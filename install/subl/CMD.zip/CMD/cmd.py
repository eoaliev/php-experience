import os, sublime_plugin
class CmdCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        os.system("cmd /K E:\\PHP-coding\\php-7.2.1\\php.exe -f " + self.view.file_name())